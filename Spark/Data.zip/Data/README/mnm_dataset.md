### MnM Dataset

This is fake data created to illustrate a small example. The code to generate this data
is `chapter2/py/src/gen_mnm_dataset.py`

